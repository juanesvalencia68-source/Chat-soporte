// server.ts
import express from "express";
import { createServer } from "http";
import { WebSocketServer, WebSocket } from "ws";
import path from "path";
import { fileURLToPath } from "url";

// src/data/initialData.ts
var INITIAL_AGENTS = [
  // --- TEAM LEADERS (ÚNICOS TEAM LEADERS OFICIALES) ---
  {
    id: "leader-jeremy",
    name: "Jeremy Adams",
    avatar: "badge-support",
    role: "Team Leader de Soporte & Seguridad",
    roleType: "team_leader",
    department: "soporte",
    departmentName: "Soporte",
    status: "online",
    statusBio: "L\xEDder t\xE9cnico y supervisor de operaciones. Supervisi\xF3n de SLA y resoluci\xF3n de casos de alto impacto.",
    email: "jeremy.adams@soporte.empresa.com",
    username: "jeremy.adams",
    password: "LeaderJeremy2026!",
    channelCode: "01",
    rating: 4.98,
    resolvedCount: 840,
    avgResponseTime: "1.0 min",
    maxAgentsLimit: 10,
    assignedAgentIds: ["agent-carlos", "agent-felipe", "agent-sofia"],
    cannedResponses: [
      {
        id: "tl-1",
        title: "Intervenci\xF3n de Team Leader",
        content: "\xA1Hola! Soy Jeremy Adams, Team Leader. He tomado tu caso directamente para garantizar una resoluci\xF3n inmediata."
      },
      {
        id: "tl-2",
        title: "Asignaci\xF3n a especialista prioritario",
        content: "He reasignado tu caso a uno de mis agentes a cargo con m\xE1xima prioridad. Te daremos respuesta inmediata."
      }
    ]
  },
  {
    id: "leader-lucas",
    name: "Lucas Wilder",
    avatar: "badge-procesos",
    role: "Team Leader de Procesos & Tr\xE1mites",
    roleType: "team_leader",
    department: "procesos",
    departmentName: "Procesos",
    status: "online",
    statusBio: "L\xEDder operativo y supervisor de tr\xE1mites, control de calidad documental y auditor\xEDa.",
    email: "lucas.wilder@procesos.empresa.com",
    username: "lucas.wilder",
    password: "LeaderLucas2026!",
    channelCode: "02",
    rating: 4.97,
    resolvedCount: 810,
    avgResponseTime: "1.1 min",
    maxAgentsLimit: 10,
    assignedAgentIds: ["agent-elena", "agent-mateo", "agent-camila"],
    cannedResponses: [
      {
        id: "tll-1",
        title: "Supervisi\xF3n de proceso especial",
        content: "\xA1Hola! Te saluda Lucas Wilder, Team Leader de Procesos. Estoy supervisando personalmente la aprobaci\xF3n de tu radicado."
      },
      {
        id: "tll-2",
        title: "Validaci\xF3n de comit\xE9 de tr\xE1mites",
        content: "Tu solicitud ha superado el filtro documental de nuestro equipo y ha sido aprobada formalmente."
      }
    ]
  },
  // --- AGENTES A CARGO ---
  {
    id: "agent-carlos",
    name: "Carlos Mendoza",
    avatar: "badge-soporte",
    role: "Especialista Senior de Soporte",
    roleType: "agent",
    department: "soporte",
    departmentName: "Soporte",
    status: "online",
    statusBio: "Resoluci\xF3n de problemas t\xE9cnicos, incidencias operativas y fallas del sistema.",
    email: "carlos.mendoza@soporte.empresa.com",
    rating: 4.96,
    resolvedCount: 428,
    avgResponseTime: "1.2 min",
    teamLeaderId: "leader-jeremy",
    teamLeaderName: "Jeremy Adams",
    cannedResponses: [
      {
        id: "c-1",
        title: "Saludo inicial de soporte",
        content: "\xA1Hola! Te atiende Carlos del \xE1rea de Soporte. Estoy revisando el registro de tu caso en el sistema para darte una pronta soluci\xF3n."
      },
      {
        id: "c-2",
        title: "Solicitar captura o detalles",
        content: "\xBFPodr\xEDas por favor compartir una captura de pantalla del error o describir el comportamiento an\xF3malo que est\xE1s experimentando?"
      },
      {
        id: "c-3",
        title: "Incidencia en resoluci\xF3n",
        content: "Hemos aislado la falla y aplicado la correcci\xF3n correspondiente. \xBFPodr\xEDas por favor verificar si ya funciona con normalidad?"
      }
    ]
  },
  {
    id: "agent-felipe",
    name: "Felipe Correa",
    avatar: "badge-soporte",
    role: "Ingeniero de Diagn\xF3stico T\xE9cnico",
    roleType: "agent",
    department: "soporte",
    departmentName: "Soporte",
    status: "online",
    statusBio: "Monitoreo de latencia, diagn\xF3stico de conexiones y estabilidad de servicios.",
    email: "felipe.correa@soporte.empresa.com",
    rating: 4.91,
    resolvedCount: 310,
    avgResponseTime: "1.4 min",
    teamLeaderId: "leader-jeremy",
    teamLeaderName: "Jeremy Adams",
    cannedResponses: [
      {
        id: "f-1",
        title: "Prueba de diagn\xF3stico",
        content: "He lanzado una prueba de diagn\xF3stico en tu sesi\xF3n y los logs indican normalidad en el servicio."
      }
    ]
  },
  {
    id: "agent-elena",
    name: "Elena Vega",
    avatar: "badge-procesos",
    role: "Especialista de Tr\xE1mites y Procesos",
    roleType: "agent",
    department: "procesos",
    departmentName: "Procesos",
    status: "online",
    statusBio: "Gesti\xF3n y validaci\xF3n de tr\xE1mites, tiempos de procesamiento y auditor\xEDa de solicitudes.",
    email: "elena.vega@procesos.empresa.com",
    rating: 4.94,
    resolvedCount: 395,
    avgResponseTime: "1.5 min",
    teamLeaderId: "leader-lucas",
    teamLeaderName: "Lucas Wilder",
    cannedResponses: [
      {
        id: "e-1",
        title: "Saludo de Procesos",
        content: "\xA1Hola! Soy Elena del departamento de Procesos. Con gusto reviso el estado de tu tr\xE1mite y la validaci\xF3n de tus requisitos."
      },
      {
        id: "e-2",
        title: "Documentaci\xF3n en revisi\xF3n",
        content: "Los soportes documentales han sido ingresados a nuestra mesa de control y est\xE1n en proceso de verificaci\xF3n formal."
      },
      {
        id: "e-3",
        title: "Tr\xE1mite completado",
        content: "Tu proceso ha sido aprobado exitosamente. Se ha generado la constancia con n\xFAmero de radicado oficial."
      }
    ]
  },
  {
    id: "agent-mateo",
    name: "Mateo Valenzuela",
    avatar: "badge-procesos",
    role: "Auditor de Procesos & Cumplimiento",
    roleType: "agent",
    department: "procesos",
    departmentName: "Procesos",
    status: "busy",
    statusBio: "Revisi\xF3n y validaci\xF3n de tr\xE1mites especiales, apelaciones y procesos corporativos.",
    email: "mateo.valenzuela@procesos.empresa.com",
    rating: 4.88,
    resolvedCount: 275,
    avgResponseTime: "1.8 min",
    teamLeaderId: "leader-lucas",
    teamLeaderName: "Lucas Wilder",
    cannedResponses: [
      {
        id: "m-1",
        title: "Validaci\xF3n de identidad",
        content: "\xA1Hola! Soy Mateo del \xE1rea de Procesos. Para continuar con el tr\xE1mite, requerimos verificar tu identidad con el documento registrado."
      }
    ]
  },
  {
    id: "agent-sofia",
    name: "Sof\xEDa Restrepo",
    avatar: "badge-estafa",
    role: "Analista de Prevenci\xF3n de Fraude & Estafas",
    roleType: "agent",
    department: "estafa",
    departmentName: "Estafa",
    status: "online",
    statusBio: "Atenci\xF3n prioritaria a reportes de fraude, suplantaci\xF3n de identidad y protecci\xF3n de fondos.",
    email: "sofia.restrepo@seguridad.empresa.com",
    rating: 4.99,
    resolvedCount: 520,
    avgResponseTime: "0.9 min",
    teamLeaderId: "leader-jeremy",
    teamLeaderName: "Jeremy Adams",
    cannedResponses: [
      {
        id: "s-1",
        title: "Protocolo urgente de estafa",
        content: "\xA1Hola! Te atiende Sof\xEDa del equipo de Seguridad & Estafas. Hemos activado el protocolo de protecci\xF3n inmediata sobre tu cuenta."
      },
      {
        id: "s-2",
        title: "Bloqueo preventivo de seguridad",
        content: "Hemos aplicado un congelamiento preventivo a las operaciones no autorizadas para salvaguardar tu saldo e informaci\xF3n sensible."
      }
    ]
  },
  {
    id: "agent-camila",
    name: "Camila R\xEDos",
    avatar: "badge-estafa",
    role: "Investigadora de Incidentes de Seguridad",
    roleType: "agent",
    department: "estafa",
    departmentName: "Estafa",
    status: "away",
    statusBio: "Trazabilidad de pagos fraudulentos, verificaci\xF3n de enlaces phishing y contenci\xF3n.",
    email: "camila.rios@seguridad.empresa.com",
    rating: 4.92,
    resolvedCount: 180,
    avgResponseTime: "1.1 min",
    teamLeaderId: "leader-lucas",
    teamLeaderName: "Lucas Wilder",
    cannedResponses: [
      {
        id: "cr-1",
        title: "Verificaci\xF3n de enlace",
        content: "El enlace que recibiste ha sido analizado y catalogado como sitio malicioso. No ingreses datos en \xE9l."
      }
    ]
  }
];
var INITIAL_TICKETS = [];
var INITIAL_MESSAGES = {};

// server.ts
var __filename = fileURLToPath(import.meta.url);
var __dirname = path.dirname(__filename);
var agents = JSON.parse(JSON.stringify(INITIAL_AGENTS));
var tickets = [];
var messages = {};
var typingState = {};
async function startServer() {
  const app = express();
  const server = createServer(app);
  const wss = new WebSocketServer({ server });
  app.use(express.json());
  function broadcast(event, payload, excludeWs) {
    const data = JSON.stringify({ event, payload });
    wss.clients.forEach((client) => {
      if (client !== excludeWs && client.readyState === WebSocket.OPEN) {
        client.send(data);
      }
    });
  }
  app.get("/api/state", (_req, res) => {
    const state = {
      agents,
      tickets,
      messages
    };
    res.json(state);
  });
  app.post("/api/clear", (_req, res) => {
    tickets = [];
    messages = {};
    broadcast("sync_state", { agents, tickets, messages });
    res.json({ success: true, message: "Todas las conversaciones de prueba fueron eliminadas." });
  });
  app.post("/api/tickets", (req, res) => {
    const { initialMessages, ...ticketData } = req.body;
    const newTicket = ticketData;
    if (!newTicket.id) {
      newTicket.id = `TICK-${Math.floor(1e3 + Math.random() * 9e3)}`;
    }
    newTicket.createdAt = newTicket.createdAt || Date.now();
    newTicket.updatedAt = Date.now();
    const existingIndex = tickets.findIndex((t) => t.id === newTicket.id);
    if (existingIndex >= 0) {
      tickets[existingIndex] = { ...tickets[existingIndex], ...newTicket };
    } else {
      tickets.unshift(newTicket);
    }
    if (!messages[newTicket.id]) {
      messages[newTicket.id] = [];
    }
    if (Array.isArray(initialMessages)) {
      initialMessages.forEach((m) => {
        if (!messages[newTicket.id].some((existing) => existing.id === m.id)) {
          messages[newTicket.id].push(m);
        }
      });
    }
    broadcast("ticket_created", newTicket);
    if (Array.isArray(initialMessages)) {
      initialMessages.forEach((m) => {
        broadcast("new_message", m);
      });
    }
    res.status(201).json(newTicket);
  });
  app.post("/api/messages", (req, res) => {
    const message = req.body;
    if (!message.id) {
      message.id = `msg-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    }
    message.timestamp = message.timestamp || Date.now();
    const ticketId = message.ticketId;
    if (!messages[ticketId]) {
      messages[ticketId] = [];
    }
    if (!messages[ticketId].some((m) => m.id === message.id)) {
      messages[ticketId].push(message);
    }
    const ticket = tickets.find((t) => t.id === ticketId);
    if (ticket) {
      ticket.updatedAt = Date.now();
      if (message.senderType !== "internal_note") {
        ticket.lastMessageSnippet = message.content.slice(0, 80);
      }
      if (message.senderType === "customer") {
        ticket.unreadCountAgent += 1;
      } else if (message.senderType === "agent") {
        ticket.unreadCountClient += 1;
        ticket.status = ticket.status === "pending" ? "in_progress" : ticket.status;
        if (!ticket.assignedAgentId && message.senderId) {
          ticket.assignedAgentId = message.senderId;
          ticket.assignedAgentName = message.senderName;
          ticket.assignedAgentRole = message.senderRole;
        }
      }
      broadcast("ticket_updated", ticket);
    }
    broadcast("new_message", message);
    res.status(201).json(message);
  });
  app.put("/api/tickets/:id", (req, res) => {
    const { id } = req.params;
    const updates = req.body;
    const ticketIndex = tickets.findIndex((t) => t.id === id);
    if (ticketIndex === -1) {
      res.status(404).json({ error: "Ticket no encontrado" });
      return;
    }
    const currentTicket = tickets[ticketIndex];
    const updatedTicket = {
      ...currentTicket,
      ...updates,
      updatedAt: Date.now()
    };
    tickets[ticketIndex] = updatedTicket;
    broadcast("ticket_updated", updatedTicket);
    res.json(updatedTicket);
  });
  app.post("/api/agents", (req, res) => {
    const agent = req.body;
    const existingIndex = agents.findIndex((a) => a.id === agent.id);
    if (existingIndex >= 0) {
      agents[existingIndex] = { ...agents[existingIndex], ...agent };
      broadcast("agent_updated", agents[existingIndex]);
      res.json(agents[existingIndex]);
    } else {
      agents.push(agent);
      broadcast("agent_created", agent);
      res.status(201).json(agent);
    }
  });
  wss.on("connection", (ws) => {
    const initialState = {
      agents,
      tickets,
      messages
    };
    ws.send(JSON.stringify({ event: "sync_state", payload: initialState }));
    ws.on("message", (data) => {
      try {
        const parsed = JSON.parse(data.toString());
        const { event, payload } = parsed;
        switch (event) {
          case "post_message": {
            const message = payload;
            if (!message.id) {
              message.id = `msg-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
            }
            message.timestamp = Date.now();
            const ticketId = message.ticketId;
            if (!messages[ticketId]) {
              messages[ticketId] = [];
            }
            messages[ticketId].push(message);
            const ticket = tickets.find((t) => t.id === ticketId);
            if (ticket) {
              ticket.updatedAt = Date.now();
              if (message.senderType !== "internal_note") {
                ticket.lastMessageSnippet = message.content.slice(0, 80);
              }
              broadcast("ticket_updated", ticket);
            }
            broadcast("new_message", message);
            break;
          }
          case "update_ticket": {
            const updated = payload;
            const index = tickets.findIndex((t) => t.id === updated.id);
            if (index >= 0) {
              tickets[index] = { ...tickets[index], ...updated, updatedAt: Date.now() };
              broadcast("ticket_updated", tickets[index]);
            }
            break;
          }
          case "create_ticket": {
            const newTicket = payload;
            if (!newTicket.id) {
              newTicket.id = `TICK-${Math.floor(1e3 + Math.random() * 9e3)}`;
            }
            newTicket.createdAt = Date.now();
            newTicket.updatedAt = Date.now();
            tickets.unshift(newTicket);
            if (!messages[newTicket.id]) {
              messages[newTicket.id] = [];
            }
            broadcast("ticket_created", newTicket);
            break;
          }
          case "typing": {
            const { ticketId, senderKey, isTyping, name, senderType } = payload;
            if (!typingState[ticketId]) {
              typingState[ticketId] = {};
            }
            typingState[ticketId][senderKey] = { isTyping, name, senderType };
            broadcast("typing_update", { ticketId, typers: typingState[ticketId] });
            break;
          }
          case "update_agent": {
            const updatedAgent = payload;
            const index = agents.findIndex((a) => a.id === updatedAgent.id);
            if (index >= 0) {
              agents[index] = { ...agents[index], ...updatedAgent };
              broadcast("agent_updated", agents[index]);
            } else {
              agents.push(updatedAgent);
              broadcast("agent_created", updatedAgent);
            }
            break;
          }
          case "reset_demo": {
            agents = JSON.parse(JSON.stringify(INITIAL_AGENTS));
            tickets = JSON.parse(JSON.stringify(INITIAL_TICKETS));
            messages = JSON.parse(JSON.stringify(INITIAL_MESSAGES));
            broadcast("sync_state", { agents, tickets, messages });
            break;
          }
          default:
            break;
        }
      } catch (err) {
        console.error("Error handling WebSocket message:", err);
      }
    });
    ws.on("close", () => {
    });
  });
  const isProduction = process.env.NODE_ENV === "production";
  if (!isProduction) {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const fs = await import("fs");
    let distPath = path.resolve(__dirname, "dist");
    if (!fs.existsSync(distPath) && fs.existsSync(path.resolve(__dirname, "index.html"))) {
      distPath = __dirname;
    }
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.resolve(distPath, "index.html"));
    });
  }
  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3e3;
  server.listen(port, "0.0.0.0", () => {
    console.log(`Server running at http://0.0.0.0:${port}`);
  });
}
startServer().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
